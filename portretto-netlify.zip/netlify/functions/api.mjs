// Portretto API — одна серверная функция на все маршруты /api/*
// Ключи fal.ai и Stripe живут только здесь (переменные окружения Netlify), браузер их не видит.
import crypto from "node:crypto";
import {
  cfg, json, HttpError, isCid, isId,
  getBalance, addCredits, spendCredit, loadJob, updateJob, update,
  falFetch, stripe, verifyStripeSignature, fulfill,
  GEN_ENDPOINTS, UPSCALER, TRANSLATOR,
} from "../lib/core.mjs";

export const config = { path: "/api/*" };

const MAX_UPSCALES = 3, MAX_TRANSLATIONS = 8;

export default async (req) => {
  const url = new URL(req.url);
  const route = url.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  try {
    if (req.method === "GET" && route === "config") return json(publicConfig());
    if (req.method === "GET" && route === "balance") return json(await balance(url.searchParams.get("cid")));
    if (req.method === "POST" && route === "stripe-webhook") return await webhook(req);
    if (req.method !== "POST") throw new HttpError(405, "method", "Method not allowed");

    const body = await req.json().catch(() => { throw new HttpError(400, "bad_json", "Bad JSON"); });
    switch (route) {
      case "job": return json(await startJob(body));
      case "fal": return json(await falProxy(body));
      case "translate": return json(await translate(body));
      case "refund": return json(await refund(body));
      case "checkout": return json(await checkout(body, req));
      case "confirm": return json(await confirm(body));
      case "admin/grant": return json(await adminGrant(body, req));
      default: throw new HttpError(404, "not_found", "Unknown route");
    }
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.code, message: e.message }, e.status);
    console.error("api error:", e);
    return json({ error: "server", message: "Server error" }, 500);
  }
};

// ---------------------------------------------------------------------------
function publicConfig() {
  const c = cfg();
  return {
    ready: !!c.falKey,
    payments: !!c.stripeKey,
    currency: c.currency,
    packages: c.packages,
    free: c.free,
    model: c.model, variants: c.variants, rounds: c.rounds, target: c.target, resolution: c.resolution, hd: c.hd,
  };
}

async function balance(cid) {
  if (!isCid(cid)) throw new HttpError(400, "bad_request", "Bad client id");
  return { credits: await getBalance(cid) };
}

// Списать 1 портрет и открыть задачу
async function startJob({ cid }) {
  const c = cfg();
  if (!c.falKey) throw new HttpError(503, "not_configured", "Service is not configured yet");
  if (!isCid(cid)) throw new HttpError(400, "bad_request", "Bad client id");
  const credits = await spendCredit(cid);
  const jobId = crypto.randomUUID();
  await update(`jobs/${jobId}`, () => ({ cid, created: Date.now(), gens: 0, ups: 0, trs: 0, reqs: {}, ok: false, refunded: false }));
  return { jobId, credits };
}

// ---------------------------------------------------------------------------
//  Прокси fal.ai: submit / status / result
// ---------------------------------------------------------------------------
const str = (v, max) => (typeof v === "string" ? v.slice(0, max) : undefined);
const isImg = (u) => typeof u === "string" && (u.startsWith("https://") || /^data:image\/(jpeg|png|webp);base64,/.test(u));

function cleanInput(endpoint, input, c) {
  if (!input || typeof input !== "object") throw new HttpError(400, "bad_request", "No input");
  if (endpoint === UPSCALER) {
    if (typeof input.image_url !== "string" || !input.image_url.startsWith("https://")) throw new HttpError(400, "bad_request", "Bad image_url");
    return { image_url: input.image_url, scale_factor: Math.max(1, Math.min(2, Number(input.scale_factor) || 2)), creativity: 0, output_format: input.output_format === "jpg" ? "jpg" : "png" };
  }
  const kind = GEN_ENDPOINTS[endpoint];
  const prompt = str(input.prompt, 30000);
  const urls = Array.isArray(input.image_urls) ? input.image_urls.filter(isImg).slice(0, 5) : [];
  if (!prompt || !urls.length) throw new HttpError(400, "bad_request", "Prompt and images are required");
  const out = { prompt, image_urls: urls, output_format: "png" };
  if (kind === "flux") {
    out.image_size = "auto";
    if (Number.isInteger(input.seed)) out.seed = input.seed;
  } else {
    out.num_images = Math.max(1, Math.min(c.variants, Math.floor(Number(input.num_images) || 1)));
    if (kind === "nbp") {
      const sys = str(input.system_prompt, 10000);
      if (sys) out.system_prompt = sys;
      out.resolution = c.resolution;          // разрешение задаёт только сервер
      out.aspect_ratio = "auto";
    }
  }
  return out;
}

async function falProxy({ cid, jobId, action, endpoint, input, requestId }) {
  const c = cfg();
  const job = await loadJob(cid, jobId);

  if (action === "submit") {
    const isGen = endpoint in GEN_ENDPOINTS, isUp = endpoint === UPSCALER;
    if (!isGen && !isUp) throw new HttpError(400, "bad_endpoint", "Endpoint not allowed");
    if (isGen && c.model !== "both" && endpoint !== c.model) throw new HttpError(400, "bad_endpoint", "Model not enabled");
    const clean = cleanInput(endpoint, input, c);
    const n = isGen ? (clean.num_images || 1) : 0;
    // резервируем лимит до вызова fal
    await updateJob(jobId, (j) => {
      if (isGen && j.gens + n > c.jobMaxGen) throw new HttpError(429, "job_limit", "Generation limit for this portrait reached");
      if (isUp && (!j.ok || j.ups >= MAX_UPSCALES)) throw new HttpError(429, "job_limit", "HD limit reached");
      return { ...j, gens: j.gens + n, ups: j.ups + (isUp ? 1 : 0) };
    });
    let sub;
    try {
      sub = await falFetch(`${c.falQueue}/${endpoint}`, { method: "POST", body: clean });
    } catch (e) {
      await updateJob(jobId, (j) => ({ ...j, gens: Math.max(0, j.gens - n), ups: Math.max(0, j.ups - (isUp ? 1 : 0)) })).catch(() => {});
      throw e;
    }
    const rid = String(sub.request_id || "");
    if (!isId(rid)) throw new HttpError(502, "upstream", "fal.ai returned no request id");
    const statusUrl = sub.status_url || `${c.falQueue}/${endpoint}/requests/${rid}/status`;
    const responseUrl = sub.response_url || `${c.falQueue}/${endpoint}/requests/${rid}`;
    await updateJob(jobId, (j) => ({ ...j, reqs: { ...j.reqs, [rid]: { statusUrl, responseUrl, endpoint } } }));
    return { requestId: rid };
  }

  const r = job.reqs?.[requestId];
  if (!r) throw new HttpError(404, "request_not_found", "Request not found");
  const trusted = (u) => typeof u === "string" && u.startsWith(c.falQueue + "/");
  if (!trusted(r.statusUrl) || !trusted(r.responseUrl)) throw new HttpError(400, "bad_request", "Untrusted url");

  if (action === "status") {
    const s = await falFetch(r.statusUrl);
    return { status: s.status, error: s.error || null };
  }
  if (action === "result") {
    const out = await falFetch(r.responseUrl);
    const images = (out.images || (out.image ? [out.image] : [])).map((i) => (typeof i === "string" ? i : i?.url)).filter(Boolean);
    if (images.length && r.endpoint in GEN_ENDPOINTS && !job.ok) await updateJob(jobId, (j) => ({ ...j, ok: true }));
    return { images };
  }
  throw new HttpError(400, "bad_action", "Unknown action");
}

// ---------------------------------------------------------------------------
//  Перевод запроса на английский (внутри оплаченной задачи)
// ---------------------------------------------------------------------------
async function translate({ cid, jobId, text }) {
  const c = cfg();
  await loadJob(cid, jobId);
  const t = str(text, 2000);
  if (!t) throw new HttpError(400, "bad_request", "No text");
  await updateJob(jobId, (j) => {
    if (j.trs >= MAX_TRANSLATIONS) throw new HttpError(429, "job_limit", "Translation limit");
    return { ...j, trs: j.trs + 1 };
  });
  const out = await falFetch(`${c.falRun}/${TRANSLATOR}`, {
    method: "POST",
    body: {
      system_prompt: "You translate a client's photo-editing request from Russian or Ukrainian into English for an AI image model. Output ONLY the English translation — precise and complete, keeping every detail (places, actions, poses, clothing, colors, lighting, body edits, amounts). Do not add, explain or soften anything. No quotes.",
      prompt: t, temperature: 0,
    },
  });
  const en = String(out.output || "").trim().replace(/^["«]|["»]$/g, "");
  return { text: en || t };
}

// ---------------------------------------------------------------------------
//  Возврат портрета, если задача не дала ни одного результата
// ---------------------------------------------------------------------------
async function refund({ cid, jobId }) {
  await loadJob(cid, jobId);
  let doRefund = false;
  await updateJob(jobId, (j) => {
    doRefund = !j.ok && !j.refunded;
    return doRefund ? { ...j, refunded: true } : j;
  });
  const credits = doRefund ? await addCredits(cid, 1, "refund") : await getBalance(cid);
  return { refunded: doRefund, credits };
}

// ---------------------------------------------------------------------------
//  Оплата Stripe
// ---------------------------------------------------------------------------
const PACK_NAMES = {
  ru: (n) => `Portretto — ${n} ${plural(n, ["портрет", "портрета", "портретов"])}`,
  uk: (n) => `Portretto — ${n} ${plural(n, ["портрет", "портрети", "портретів"])}`,
  en: (n) => `Portretto — ${n} ${n === 1 ? "portrait" : "portraits"}`,
};
function plural(n, [one, few, many]) {
  const a = n % 10, b = n % 100;
  if (a === 1 && b !== 11) return one;
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return few;
  return many;
}

async function checkout({ cid, pack, lang }, req) {
  const c = cfg();
  if (!isCid(cid)) throw new HttpError(400, "bad_request", "Bad client id");
  const p = c.packages.find((x) => x.id === pack);
  if (!p) throw new HttpError(400, "bad_pack", "Unknown package");
  const origin = c.siteUrl || new URL(req.url).origin;
  const name = (PACK_NAMES[lang] || PACK_NAMES.en)(p.portraits);
  const s = await stripe("checkout/sessions", {
    method: "POST",
    params: {
      mode: "payment",
      success_url: `${origin}/?paid={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?canceled=1`,
      client_reference_id: cid,
      locale: "auto",
      line_items: { 0: { quantity: 1, price_data: { currency: c.currency, unit_amount: p.price, product_data: { name } } } },
      metadata: { cid, portraits: p.portraits, pack: p.id },
      payment_intent_data: { metadata: { cid, portraits: p.portraits, pack: p.id } },
    },
  });
  if (!s.url) throw new HttpError(502, "stripe", "Stripe returned no checkout url");
  return { url: s.url };
}

// Возврат с оплаты: зачисляем сразу, не дожидаясь webhook (повторно не зачислится)
async function confirm({ cid, sessionId }) {
  if (!isCid(cid)) throw new HttpError(400, "bad_request", "Bad client id");
  const r = await fulfill(sessionId);
  const own = r.cid === cid;
  return { added: own ? r.added : 0, pending: !!r.pending, already: own && !!r.already, processing: !!r.processing, credits: await getBalance(cid), other: !own };
}

async function webhook(req) {
  const c = cfg();
  const payload = await req.text();
  if (!verifyStripeSignature(payload, req.headers.get("stripe-signature"), c.whSecret)) {
    return json({ error: "bad_signature" }, 400);
  }
  let event;
  try { event = JSON.parse(payload); } catch { return json({ error: "bad_json" }, 400); }
  if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
    const r = await fulfill(event.data?.object?.id);
    return json({ received: true, added: r.added || 0 });
  }
  return json({ received: true });
}

// ---------------------------------------------------------------------------
//  Админ: начислить портреты вручную (заголовок x-admin-token = ADMIN_TOKEN)
// ---------------------------------------------------------------------------
async function adminGrant({ cid, add }, req) {
  const c = cfg();
  const token = req.headers.get("x-admin-token") || "";
  const ok = c.adminToken && token.length === c.adminToken.length &&
    crypto.timingSafeEqual(Buffer.from(token), Buffer.from(c.adminToken));
  if (!ok) throw new HttpError(403, "forbidden", "Forbidden");
  if (!isCid(cid)) throw new HttpError(400, "bad_request", "Bad client id");
  const n = Math.floor(Number(add));
  if (!Number.isFinite(n) || n === 0 || Math.abs(n) > 1000) throw new HttpError(400, "bad_request", "Bad amount");
  return { credits: await addCredits(cid, n, n > 0 ? "admin" : "admin-") };
}
